package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LabTestDetailsActivity extends AppCompatActivity {
TextView tv1,tv2;
EditText ed1;
Button AddToCart,LabTestBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_test_details);
        tv1=findViewById(R.id.textViewBuyTitle);
        tv2=findViewById(R.id.textViewTotalprice);
        ed1=findViewById(R.id.editTextBuy);
        AddToCart=findViewById(R.id.buttonBuy);
        LabTestBack=findViewById(R.id.btnBuyBack);
        ed1.setKeyListener(null);
        Intent intent=getIntent();
        tv1.setText(intent.getStringExtra("text1"));
        ed1.setText(intent.getStringExtra("text2"));
        tv2.setText("Total Cost:"+intent.getStringExtra("text3")+"/-");
        LabTestBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LabTestDetailsActivity.this,LabTestActivity.class));
            }
        });
        AddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences=getSharedPreferences("shared prefs", Context.MODE_PRIVATE);
                String username=sharedPreferences.getString("username","").toString();
                String product=tv1.getText().toString();
                float price=Float.parseFloat(intent.getStringExtra("text3").toString());
                DatabaseConnection db=new DatabaseConnection(getApplicationContext(),"healthcare",null,1);
                if(db.checkCart(username,product)==1)
                {
                    Toast.makeText(getApplicationContext(),"Product Already Added",Toast.LENGTH_SHORT).show();
                }
                else {
                    db.addCart(username,product,price,"lab");
                    Toast.makeText(getApplicationContext(),"Record Inserted To Cart",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(LabTestDetailsActivity.this,LabTestActivity.class));
                }
            }
        });
    }
}