package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class BuyMedicineActivity extends AppCompatActivity {
private String[][] packages=
        {
                {"Acetaminophen","","","","50"},
                {"Adderall","","","","60"},
                {"Amitriptyline","","","","70"},
                {"Amlodipine","","","","80"},
                {"Amoxicillin","","","","90"},
                {"Ativan","","","","100"},
                {"Atorvastatin","","","","150"},
                {"Azithromycin","","","","80"},
                {"Losartan","","","","70"},

        };
private String[] package_details={
  "Building and Keeping the Bons & teeth strong\n"+
          "Reducing Fatique/stress and muscular pains\n"+
          "Boosting immunity and increasing resistance against infection\n"+
          "Chromium is an essential  trace mineral that plays an important role in helping insulin regulate blood glucose.",
          "Provide relief from vitamin B deficiencies\n"+
                  "Helps in formation of red blood cells\n"+
                  "Maintain Healthy nervous system",
        "It promotes health as well as skin benefits\n"+
                "It Helps reduce skin blemish and pigmentation\n"+
                "It act as safegaurd the skin from the harsh UVA AND UVB sun rays",
        "Dolo 650 tablet help and releive pain and fever by blocking the release of certain chemical measuresure  responsible for fever and pain",
        "helps relieve fever and bring down a high temperature\n"+
                "suitable for people with heart condition or high blood pressure",
        "Relieves symtoms of a bactorial throat infection and soothes for recovery process\n"+
                "Provides the warm and conforting feeling during score throat",
        "reduces the risk of calcium defeciency,Rickets andOsteoporosis\n"+
                "Promotes mobolity andflexibility of joints",
        "Helps to reduce the iron deficiency due to chronic blood less or less intake of blood"
};
    Button back1,buy;
    ArrayList list;
    HashMap<String,String> item;
    ListView lst;
    SimpleAdapter sa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_medicine);
        lst=findViewById(R.id.listviewBm);
        back1=findViewById(R.id.btnBuyBack);
        buy=findViewById(R.id.buttonBuy);
        buy.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BuyMedicineActivity.this,CartBuyMedicineActivity.class));
            }
        });
        back1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BuyMedicineActivity.this,HomeActivity.class));
            }
        });
        list=new ArrayList();
        for(int i=0;i<packages.length;i++)
        {
            item=new HashMap<String,String>();
            item.put("line1",packages[i][0]);
            item.put("line2",packages[i][1]);
            item.put("line3",packages[i][2]);
            item.put("line4",packages[i][3]);
            item.put("line5","Total Cost:"+packages[i][4]+"/-");
            list.add(item);
        }
        sa=new SimpleAdapter(this,list,
                R.layout.multi_lines,
                new String[]{"line1","line2","line3","line4","line5"},
                new int[]{R.id.line_a,R.id.line_b,R.id.line_c,R.id.line_d,R.id.line_e});
        lst.setAdapter(sa);
        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent it=new Intent(BuyMedicineActivity.this,BuyMedicineDetailsActivity.class);
                it.putExtra("text1",packages[i][0]);
                it.putExtra("text2",package_details[i]);
                it.putExtra("text3",packages[i][4]);
                startActivity(it);
            }
        });
    }
}