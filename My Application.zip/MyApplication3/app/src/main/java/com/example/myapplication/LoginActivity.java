package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
Button login;
    Context context;
TextView register;
EditText user,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login=(Button)findViewById(R.id.button);
        register=(TextView) findViewById(R.id.textView3);
        user=(EditText)findViewById(R.id.editTextText);
        pass=(EditText)findViewById(R.id.editTextTextPassword);
        login.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {

             String username=user.getText().toString();
                String password=pass.getText().toString();
                DatabaseConnection db=new DatabaseConnection(getApplicationContext(),"healthcare",null,1);

                if(username.length()==0 || password.length()==0)
                {
                    Toast.makeText(getApplicationContext(), "Enter Username or Password", Toast.LENGTH_SHORT).show();
                }
                else {
                    if(db.Login(username,password)==1) {
                        Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_SHORT).show();
                        SharedPreferences sharedPreferences=getSharedPreferences("shared prefs",Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor=sharedPreferences.edit();
                        editor.putString("username",username);
                        editor.apply();
                        startActivity(new Intent(LoginActivity.this,HomeActivity.class));
                    }
                    else {
                        Toast.makeText(getApplicationContext(),"Invalid username or password",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        register.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {

                Intent intent=new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}